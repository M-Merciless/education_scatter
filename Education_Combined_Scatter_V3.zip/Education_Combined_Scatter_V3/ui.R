
#-------------------------------------------------------------------------------------------
# Define UI for application that: tab1 -  draws scatterplots dependant on variable selection
#                                 tab2 - produces facet wrap time series of all available 
#                                        budgets for selected school

UI <- shinyUI(
  #specify theme palette "cerulean"
  fluidPage(theme = shinytheme("cerulean"),
            #set app title and a browser title
            titlePanel("Schools Analysis",
                       windowTitle = "School Finance"),
            
#specify a tabset layout, allowing navigation between tabs, allowing more space for scatterplots
tabsetPanel(type = "tabs",


#===================================tabPanel1==================================================            
            #title to denote tab 1
tabPanel("Education Finance 2017-18",  
         #set out boundary box around input selections
wellPanel(
  #use rows to align elements on page
  fluidRow(
    #first column dimensions specified for x axis input
    column(4, offset = 1,
           
  #-----------------------------------------------------------------------------------------
  #x axis selection input
  #title panel to denote relevant data set
           titlePanel("Delegated School Budgets (£ thousand)"),
           #drop down input with specified column name selections
           selectInput(inputId = "x_axis_1",
                   label = "X axis variable selection: ",
                   choices = 
                     
                     c("Number of Pupils",
                       "Individual Schools Budget",
                       "Notional SEN Budget",
                       "Non ISB Funds Devolved to Schools"),
                   selected = "Number of Pupils")),
    #second column dimensions specified within first fluid row
    column(4, offset = 2,
           
           # title to specify associated dataset
           titlePanel("Delegated School Outturn Expenditure (£ thousand)"),
           #drop down input with selections specified
           selectInput(inputId = "x_axis_2",
                       label = "X axis variable selection: ",
                       choices = 
                         
                         c("Number of Pupils",
                           "Planned Budget Share",
                           "In Year Adjustments to Planned Budget Share",
                           "Other In-Year Increases / Decreases to Budget",
                           "Total LEA Resources Available to School",
                           "Reserves Brought Forward",
                           "Reserves Carried Forward",
                           "Total School Expenditure",
                           "Income Including Grants"),
                       selected = "Number of Pupils"))
    ),#end of first fluid row
  #----------------------------------------------------------------------------------------------------------
  #y axis selection input
  #second fluid row
fluidRow(
      #first column within fluidrow 2 dimensions specified
      column(4, offset = 1,   
             #dropdown for y axis selection with choices specified
       selectInput("y_axis_1",
                   "Y axis variable selection: ",
                   choices =
                     c("Number of Pupils",
                       "Individual Schools Budget",
                       "Notional SEN Budget",
                       "Non ISB Funds Devolved to Schools"),
                   selected = "Individual Schools Budget")),
      #second column dimensions specified
      column(4, offset = 2,   
             #dropdown for second y axis selection with choices specified
             selectInput("y_axis_2",
                         "Y axis variable selection: ",
                         choices =
                           c("Number of Pupils",
                             "Planned Budget Share",
                             "In Year Adjustments to Planned Budget Share",
                             "Other In-Year Increases / Decreases to Budget",
                             "Total LEA Resources Available to School",
                             "Reserves Brought Forward",
                             "Reserves Carried Forward",
                             "Total School Expenditure",
                             "Income Including Grants"),
                         selected = "Total School Expenditure"))
      ), #end of second fluid row
     
  #======================================================================================================
  #Phase selection inputs
  #third row for phase input selection
  fluidRow(
    #first column for graph 1 inputs, dimensions specified
    column(4, offset = 1,
           #as 5 levels available, use radiobuttons selection to display to end user, inline to preserve
           #vertical space
           radioButtons("phase_choice_1",
                        "Please select a phase",
                        choices = c("Nursery",
                                    "Primary",
                                    "Secondary",
                                    "Middle",
                                    "Special"),
                        selected = "Primary",
                        inline = T)),
    #second column for graph 2 inputs
    column(4, offset = 2,
           radioButtons("phase_choice_2",
                        "Please select a phase",
                        choices = c("Nursery",
                                    "Primary",
                                    "Secondary",
                                    "Middle",
                                    "Special"),
                        selected = "Primary",
                        inline = T))
    ) #end of fluid row
  
  ), #end of well panel
    
  #__________________________________________________________________________________________________________
  #__________________________________________________________________________________________________________
  ##################Outputs#####################
  
     #Show plot titles of selected axes variables
#fluid row for titles to appear above respective scatterplots
  fluidRow(
  #dimension of title column 1
    column(4, offset = 1,
           #render html formatted text in response to user selections
           htmlOutput(outputId = "chartTitle_1")
    ),
    #dimension of title column 2
    column(4, offset = 2,
           #render html formatted text in response to user selections
           htmlOutput(outputId = "chartTitle_2")
    )
    ), #end of fluid row
    
  #========================================================================================================
  #Show scatterplots rendered by axes selection
  
    fluidRow(
      #specify half page width for chart 1
      column(6,
             #render plotly graphs in response to user selected axes
             plotlyOutput(outputId = "scatterplot_1")
      ),
      #specify half page width for chart 2
      column(6,
            #render plotly graphs in response to user selected axes
             plotlyOutput(outputId = "scatterplot_2"))
             
    ), #end of fluid row
br(), #html horizontal line break for visual spacing

#===================================================================================================
#show source data link for each graph
#define final fluid row of ui to house source data hyperlinks
fluidRow(
  column(4, offset = 2,
         #html tag specifying link text
a("Data Source: Stats Wales",
  #href containing url to follow on user click
  href = "https://statswales.gov.wales/Catalogue/Local-Government/Finance/Revenue/Delegated-School-Budgets/delegatedschoolbudgets-by-school")
),

column(4, offset = 2,
       #html tag for link text
a("Data Source: Stats Wales",
  #href containing url for dataset 2
  href = "https://statswales.gov.wales/Catalogue/Local-Government/Finance/Revenue/Delegated-School-Outturn/delegatedschooloutturnexpenditure-by-school")
)
) #end of fluid row

), #end of tabpanel 1

#=====================================tabPanel 2=====================================
#text to identify second tab
tabPanel("Time Series",
         #sidebar to contain input selections
              sidebarLayout(
                sidebarPanel(
              
                  #hierarchical input dropdown. choices defined by levels in local authority factor
                selectInput(
                  inputId = "LA_Selection",
                  label = "1. Select a Local Authority",
                  choices = levels(schools_long$Local.Authority)
                ),
                
                #hierarchical input dropdown. choices set to NULL as these will be defined in server,
                #filtered by selection of local authority in hierarchy
                selectInput(
                  inputId = "school_Selection",
                  label = "2. Select a school",
                  choices = NULL,
                  selectize = TRUE
                )
                
                
              ), #end of sidebar panel
         #____________________________________________________________________________________
         #mainpanel to maximise space for facet line chart time series
         #Show time_series 
         mainPanel(   
           
           uiOutput('render_plots')
           
           #renders plotly time series dependant on user selected school, height specified
                  # plotlyOutput(outputId = "time_series_facet", height=1000)
                  )
         
              ) #sidebarLayout finishes

#=======================================================================================================

) #tabpanel2 finishes

) #tabsetpanel finishes

) #fluidpage finishes

) #ShinyUI finishes
