list.of.packages <- c("shiny", "tidyverse", "stringi", "plotly", "shinythemes") #list of packages required to run
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])] #identifies packages not yet installed and required for this app
if(length(new.packages)) install.packages(new.packages) #if there are any new packages, install them

library(shiny)
library(tidyverse)
library(stringi) # to use tri_sub()
library(plotly) #to add interactivity to plot
library(shinythemes) #apply aesthetic theme


setwd(dirname(rstudioapi::getSourceEditorContext()$path))



#Read in csv data
schoolsData <- read.csv("combined_school_finance.csv")

names(schoolsData)

#Rename column

names(schoolsData)[8] <- "Individual.schools.budget.per.pupil"

#levels(schoolsData$Local.Authority)
#str(schoolsData$Year_ItemName_ENG)

#filter to financial year 2017-18 for single year analysis in first tab

schools_1718 <- schoolsData %>%
  subset(Year_ItemName_ENG == "2017-18")

#user-friendly colnames for user selection and generated chart titles
#names(schools_1718)
names(schools_1718)[6] <- "Financial Year"
names(schools_1718)[7] <- "Individual Schools Budget"
names(schools_1718)[8] <- "ISB Per Pupil (£)"
names(schools_1718)[9] <- "Non ISB Funds Devolved to Schools"
names(schools_1718)[10] <- "Notional SEN Budget"
names(schools_1718)[11] <- "Number of Pupils"
names(schools_1718)[12] <- "In Year Adjustments to Planned Budget Share"
names(schools_1718)[13] <- "Income Including Grants"
names(schools_1718)[14] <- "Other In-Year Increases / Decreases to Budget"
names(schools_1718)[15] <- "Planned Budget Share"
names(schools_1718)[16] <- "Reserves Brought Forward"
names(schools_1718)[17] <- "Reserves Carried Forward"
names(schools_1718)[18] <- "Total LEA Resources Available to School"
names(schools_1718)[19] <- "Total School Expenditure"
names(schools_1718)[20] <- "Local Authority"



#Replace Phase values to user friendly for chart titles
schools_1718$Phase <- sub("N", "Nursery", schools_1718$Phase)
schools_1718$Phase <- sub("P", "Primary", schools_1718$Phase)
schools_1718$Phase <- sub("S", "Secondary", schools_1718$Phase)
schools_1718$Phase <- sub("M", "Middle", schools_1718$Phase)
schools_1718$Phase <- sub("X", "Special", schools_1718$Phase)

#unique(schools_1718$Phase)


#----------------------------------------------------------------------
#read in long format file for time series

schools_long <- read.csv("combined_school_finance_long.csv")


#Rename to a user friendly colname for display as tooltip on hover in plotly

names(schools_long)[8] <- "Financial Year"

options(browser="C:/Program Files (x86)/Google/Chrome/Application/chrome.exe")

#call to launch app browser on execution of run
runApp(launch.browser = T)

