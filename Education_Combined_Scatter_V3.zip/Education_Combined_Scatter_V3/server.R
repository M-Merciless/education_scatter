
# Define server logic, referencing inputs and outputs in ui, and session for observe and update calls
server <- function(input, output, session) {
  
  #================reactive title logic=====================================================    
  
  #generate chart title for first chart in reactive wrappers ({})
  output$chartTitle_1 <- renderText({ 
    #store pasted html formatted title
    generated_text_1 <- paste(tags$h4(tags$b(input$phase_choice_1),
                                      "Phase Scatterplot: ",
                                      tags$b(input$y_axis_1),
                                      "as a function of ",
                                      tags$b(input$x_axis_1),
                                      "for",
                                      tags$b(nrow(schools_selected_1())),
                                      "schools."))
    #and paste html reactive chart title 1
    HTML(paste(generated_text_1))
  })
  
  #2nd reactive chart title
  output$chartTitle_2 <- renderText({ 
    generated_text_2 <- paste(tags$h4(tags$b(input$phase_choice_2),
                                      "Phase Scatterplot: ",
                                      tags$b(input$y_axis_2),
                                      "as a function of ",
                                      tags$b(input$x_axis_2),
                                      "for",
                                      tags$b(nrow(schools_selected_2())),
                                      "schools."
    ))
    HTML(paste(generated_text_2))
  })
  
  #==========================================================================================================  
  #=================================Scatterplot Data Subsetting========================================================
  
  
  # Filter schools_1718 for selected education Phase, used to plot chart 1
  schools_selected_1 <- reactive({
    filter(schools_1718, Phase %in% input$phase_choice_1)
  })
  
  # Same filter call for input_2, used to plot chart 2
  schools_selected_2 <- reactive({
    filter(schools_1718, Phase %in% input$phase_choice_2)
  })
  
  #=========================================================================================================
  #======================================Render scatterplots using datasets above ==========================
  
  # Plot selected variables, must use aes_string as input calls have a character structure
  #must use paste0 and backticks to deal with non-standard names (spaces in colnames)
  
  output$scatterplot_1 <- renderPlotly({
    # print(input$x_axis_1)
    static_1 <- ggplot(
      data = schools_selected_1(), aes_string(x = paste0("`", input$x_axis_1, "`"),
                                              y = paste0("`", input$y_axis_1, "`"),
                                              #specify schoolname as label to identify school on hover
                                              label = "schoolname")) +
      geom_point(alpha = 0.3) + # transparency set to 30% to mitigate overplotting
      geom_smooth() #smoothing curve to show regression line and interquartile range
    
    
    
  })
  #-------------------------------------------------------------------------------------------------------
  
  # Same plot call for scatterplot_2
  output$scatterplot_2 <- renderPlotly({
    
    static_2 <- ggplot(
      data = schools_selected_2(), aes_string(x = paste0("`", input$x_axis_2, "`"),
                                              y = paste0("`", input$y_axis_2, "`"),
                                              label = "schoolname")) +
      geom_point(alpha = 0.3) +
      geom_smooth()
    
    ggplotly(static_2)
    
    
  })
  
  #=============================================================================================
  #Tabpanel 2 logic
  #=============================================================================================
  
  
  #Updating the hierarchical slicer for local authority selection
  
  #observe the local authority selection, filter choices if user changes and update the school selection choices
  observe({
    # print(input$LA_Selection)
    
    #filter the data based upon input selection then select the schoolname column for these filtered rows    
    LA_user_selected <- schools_long %>%
      subset(Local.Authority == input$LA_Selection) %>%
      select(schoolname)
    
    #update the school selection input within this session, specifying choices as unique (duplicates removed)
    # schoolnames selected in above local authority filter call
    
    updateSelectInput(session, "school_Selection", choices = unique(LA_user_selected)
                      
    ) #end of updateSelectInput
    
    
  })#end of observe
  
  #-----------------------------------------------------------------------------------------------------------
  #################################Data filter to create facets###############################################
  
  
  # Filter schoolsData for input hierarchy selections. Based on selected school as this is lowest
  #level of ranularity in the data
  
  hierarchy_selection <- reactive({
    data <- subset(schools_long, schoolname %in% input$school_Selection)
    
    # write.csv(data, 'C:/Users/richard.leyshon/OneDrive - Wales Audit Office/Documents/Education/Education Scatter/Education_Combined_Scatter_V3/TEST DATA.csv')
    # 
    # data
    
  })
  
  
  # plotVariables <- reactiveValues(plot = NULL)
  
  
  
  
  
  observe({
    
    variables <- unique(hierarchy_selection()$Column_ItemName_ENG) 
    
    # Render UI elements in a loop based on reactive element -
    # the number of Items available to that school(variables)
    output$render_plots <- renderUI({
      
      lapply(variables, function(i){
        
        plotlyOutput(paste0('plot_', gsub(" ", "", i)))
        
      })
      
      
    })
    
    
    # Do the same as above but create a plot based on the above UI calls
    # i.e. if there's 5 variables, create 5 plots 
    lapply(variables, function(i){
      
      output[[paste0('plot_', gsub(" ", "", i))]] <- renderPlotly({
        
        g <- hierarchy_selection() %>%
          filter(Column_ItemName_ENG == i) %>% 
          ggplot(aes(x = (`Financial Year`), y = (Data))) +
          geom_line(group = 1) +
          theme(axis.text.x=element_text(angle=45, hjust=1)) + 
          ggtitle(as.character(i))
        
        
        return(ggplotly(g))
            

        
      })
      
    })
    
  })
  
  
  
  #===========================================================================================================
  #Plot time series of selected school
  
  
  #render plotly facet in response to user selected school
  
  # output$time_series_facet <- renderPlotly({
  # 
  #   #produce static facet wrap  
  #   time_series_static <- ggplot(
  #     
  #     data = hierarchy_selection(), aes(x = (`Financial Year`),
  #                                       y = (Data))) +
  #     geom_line(group = 1) +
  #       facet_wrap(vars((Column_ItemName_ENG)), 
  #                 scales = "free_y",
  #                 ncol=3) + 
  #     theme(axis.text.x=element_blank(), 
  #           axis.ticks.x=element_blank(), 
  #           panel.spacing = unit(1, "lines")) 
  #   
  # 
  # 
  #   ggplotly(time_series_static) #pass static facet to ggplotly for interactivity
  #   
  # 
  # }) #end of render plotly
  
} #end of server


